
ImageInfo - A JavaScript library for reading image metadata.
Copyright (c) 2008 Jacob Seidelin, jseidelin@nihilogic.dk, http://blog.nihilogic.dk/
MIT License [http://www.nihilogic.dk/licenses/mit-license.txt]

For detailed information and code samples please refer to the blog post at:
http://blog.nihilogic.dk/2008/07/imageinfo-reading-image-info-with-javascript.html
